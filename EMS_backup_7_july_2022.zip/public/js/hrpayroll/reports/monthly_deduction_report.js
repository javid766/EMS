(function($) {
	'use strict';
	$('select').select2();
})(jQuery);